*version 9.1 855027322
u 33
U? 2
V? 2
R? 2
? 3
@libraries
@analysis
.TRAN 1 0 0 0
+0 0
+1 1
.OP 0 
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 1949 
@status
n 0 126:05:10:09:11:27;1781107887 e 
s 2832 126:05:10:12:36:38;1781120198 e 
*page 1 0 970 720 iA
@ports
port 4 GND_EARTH 280 280 h
port 5 GND_EARTH 320 320 h
@parts
part 23 r 330 320 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R1
a 0 ap 9 0 15 0 hln 100 REFDES=R1
part 3 vsin 290 280 v
a 0 a 0:13 0 0 0 hln 100 PKGREF=V1
a 1 ap 9 0 20 10 hcn 100 REFDES=V1
a 1 u 0 0 0 0 hcn 100 VOFF=0
a 1 u 0 0 0 0 hcn 100 VAMPL=5
a 1 u 0 0 0 0 hcn 100 FREQ=5
part 2 opamp 400 280 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U1
a 0 ap 9 0 14 0 hln 100 REFDES=U1
part 1 titleblk 970 720 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 300 95 hrn 100 PAGENO=1
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
part 31 nodeMarker 480 300 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=2
part 30 nodeMarker 330 280 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=1
@conn
w 21
a 0 up 0:33 0 0 0 hln 100 V=
s 290 280 280 280 19
a 0 up 33 0 285 279 hct 100 V=
w 29
a 0 up 0:33 0 0 0 hln 100 V=
s 330 320 320 320 27
a 0 up 33 0 325 319 hct 100 V=
w 18
a 0 up 0:33 0 0 0 hln 100 V=
s 330 280 400 280 20
a 0 up 33 0 365 279 hct 100 V=
w 8
a 0 up 0:33 0 0 0 hln 100 V=
s 380 320 400 320 12
s 380 320 380 360 10
s 380 360 480 360 13
a 0 up 33 0 430 359 hct 100 V=
s 480 360 480 300 15
s 380 320 370 320 24
@junction
j 400 320
+ p 2 -
+ w 8
j 480 300
+ p 2 OUT
+ w 8
j 290 280
+ p 3 +
+ w 21
j 280 280
+ s 4
+ w 21
j 330 280
+ p 3 -
+ w 18
j 400 280
+ p 2 +
+ w 18
j 370 320
+ p 23 2
+ w 8
j 380 320
+ w 8
+ w 8
j 330 320
+ p 23 1
+ w 29
j 320 320
+ s 5
+ w 29
j 330 280
+ p 30 pin1
+ p 3 -
j 330 280
+ p 30 pin1
+ w 18
j 480 300
+ p 31 pin1
+ p 2 OUT
j 480 300
+ p 31 pin1
+ w 8
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
