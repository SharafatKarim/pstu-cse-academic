*version 9.1 409101418
u 66
U? 6
R? 6
V? 2
@libraries
@analysis
.TRAN 0 0 0 0
+0 0
+1 1
.OP 0 
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 2379 
@status
n 0 126:05:09:13:57:16;1781038636 e 
s 2832 126:05:09:13:57:20;1781038640 e 
*page 1 0 970 720 iA
@ports
port 3 GND_EARTH 310 260 h
port 64 GND_ANALOG 90 530 h
@parts
part 5 r 190 290 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R1
a 0 ap 9 0 15 0 hln 100 REFDES=R1
part 52 r 340 350 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R5
a 0 ap 9 0 15 0 hln 100 REFDES=R5
part 2 opamp 310 260 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U1
a 0 ap 9 0 14 0 hln 100 REFDES=U1
part 6 vdc 90 490 h
a 0 sp 0 0 22 37 hln 100 PART=vdc
a 0 a 0:13 0 0 0 hln 100 PKGREF=V1
a 1 ap 9 0 24 7 hcn 100 REFDES=V1
a 1 u 13 0 -11 18 hcn 100 DC=10V
part 4 Sw_tOpen 120 280 h
a 0 sp 0 0 0 24 hln 100 PART=Sw_tOpen
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U2
a 0 ap 9 0 0 20 hln 100 REFDES=U2
a 0 u 13 13 0 -4 hln 100 tOpen=0
part 1 titleblk 970 720 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 300 95 hrn 100 PAGENO=1
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
@conn
w 27
a 0 up 0:33 0 0 0 hln 100 V=
s 160 290 190 290 26
a 0 up 33 0 175 289 hct 100 V=
w 59
a 0 up 0:33 0 0 0 hln 100 V=
s 380 350 410 350 58
s 410 350 410 280 60
a 0 up 33 0 412 315 hlt 100 V=
s 410 280 390 280 62
w 49
a 0 up 0:33 0 0 0 hln 100 V=
s 230 290 260 290 34
s 260 290 260 300 36
s 260 300 300 300 38
s 260 340 260 300 42
s 300 300 310 300 55
s 300 300 300 350 53
a 0 up 33 0 302 325 hlt 100 V=
s 300 350 340 350 56
w 14
a 0 up 0:33 0 0 0 hln 100 V=
s 90 490 90 440 13
s 90 290 120 290 15
s 90 340 90 290 19
s 120 340 90 340 17
s 90 390 90 340 22
s 120 390 90 390 20
s 90 440 90 390 25
a 0 up 33 0 92 415 hlt 100 V=
s 120 440 90 440 23
@junction
j 310 260
+ s 3
+ p 2 +
j 380 350
+ p 52 2
+ w 59
j 390 280
+ p 2 OUT
+ w 59
j 120 290
+ p 4 1
+ w 14
j 160 290
+ p 4 2
+ w 27
j 90 490
+ p 6 +
+ w 14
j 90 530
+ s 64
+ p 6 -
j 190 290
+ p 5 1
+ w 27
j 230 290
+ p 5 2
+ w 49
j 90 340
+ w 14
+ w 14
j 90 390
+ w 14
+ w 14
j 90 440
+ w 14
+ w 14
j 310 300
+ p 2 -
+ w 49
j 260 300
+ w 49
+ w 49
j 300 300
+ w 49
+ w 49
j 340 350
+ p 52 1
+ w 49
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
