* Schematics Aliases *

.ALIASES
R_R1            R1(1=$N_0002 2=$N_0001 )
R_R5            R5(1=$N_0001 2=$N_0003 )
E_U1            U1(OUT=$N_0003 +=0 -=$N_0001 )
V_V1            V1(+=$N_0004 -=0 )
X_U2            U2(1=$N_0004 2=$N_0002 )
.ENDALIASES

