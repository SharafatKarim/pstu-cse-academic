* Schematics Aliases *

.ALIASES
R_R2            R2(1=$N_0002 2=$N_0001 )
R_R3            R3(1=0 2=$N_0002 )
V_V1            V1(+=$N_0003 -=0 )
R_R5            R5(1=$N_0003 2=$N_0004 )
L_L3            L3(1=$N_0004 2=0 )
E_U1            U1(OUT=$N_0001 +=$N_0004 -=$N_0002 )
.ENDALIASES

