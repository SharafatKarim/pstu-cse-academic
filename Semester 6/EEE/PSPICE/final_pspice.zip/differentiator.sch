*version 9.1 565976818
u 33
V? 2
C? 2
U? 2
R? 2
? 3
@libraries
@analysis
.TRAN 1 0 0 0
+0 0
+1 1
.TF 0  
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 2301 
@status
n 0 126:05:09:12:04:18;1781031858 e 
s 0 126:05:09:12:04:22;1781031862 e 
*page 1 0 970 720 iA
@ports
port 7 GND_EARTH 310 270 h
port 6 GND_EARTH 170 310 h
@parts
part 5 r 380 380 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R1
a 0 ap 9 0 15 0 hln 100 REFDES=R1
part 4 opamp 350 270 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U1
a 0 ap 9 0 14 0 hln 100 REFDES=U1
part 2 vsin 190 310 v
a 0 a 0:13 0 0 0 hln 100 PKGREF=V1
a 1 ap 9 0 20 10 hcn 100 REFDES=V1
a 1 u 0 0 0 0 hcn 100 VOFF=0
a 1 u 0 0 0 0 hcn 100 FREQ=5
a 1 u 0 0 0 0 hcn 100 VAMPL=1
part 3 c 280 310 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C1
a 0 ap 9 0 15 0 hln 100 REFDES=C1
a 0 u 13 0 15 25 hln 100 VALUE=100000n
part 1 titleblk 970 720 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 300 95 hrn 100 PAGENO=1
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
part 31 nodeMarker 230 310 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=1
part 32 nodeMarker 450 290 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=2
@conn
w 9
a 0 up 0:33 0 0 0 hln 100 V=
s 310 270 350 270 8
a 0 up 33 0 330 269 hct 100 V=
w 11
a 0 up 0:33 0 0 0 hln 100 V=
s 350 310 340 310 10
s 340 310 310 310 20
s 340 310 340 380 18
a 0 up 33 0 342 345 hlt 100 V=
s 340 380 380 380 21
w 16
a 0 up 0:33 0 0 0 hln 100 V=
s 170 310 190 310 15
a 0 up 33 0 180 309 hct 100 V=
w 13
a 0 up 0:33 0 0 0 hln 100 V=
s 230 310 280 310 29
a 0 up 33 0 255 309 hct 100 V=
w 24
a 0 up 0:33 0 0 0 hln 100 V=
s 420 380 450 380 23
s 450 380 450 290 25
a 0 up 33 0 452 335 hlt 100 V=
s 450 290 430 290 27
@junction
j 350 270
+ p 4 +
+ w 9
j 310 270
+ s 7
+ w 9
j 310 310
+ p 3 2
+ w 11
j 350 310
+ p 4 -
+ w 11
j 340 310
+ w 11
+ w 11
j 380 380
+ p 5 1
+ w 11
j 420 380
+ p 5 2
+ w 24
j 430 290
+ p 4 OUT
+ w 24
j 280 310
+ p 3 1
+ w 13
j 170 310
+ s 6
+ w 16
j 230 310
+ p 31 pin1
+ w 13
j 450 290
+ p 32 pin1
+ w 24
j 230 310
+ p 2 -
+ w 13
j 190 310
+ p 2 +
+ w 16
j 230 310
+ p 31 pin1
+ p 2 -
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
