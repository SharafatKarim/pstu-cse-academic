*version 9.1 97313
u 97
U? 3
C? 4
R? 9
V? 2
? 2
@libraries
@analysis
.AC 1 3 0
+0 101
+1 10
+2 10000K
.OP 0 
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 3883 
@status
n 0 126:05:09:16:24:55;1781047495 e 
s 2832 126:05:11:08:15:18;1781190918 e 
*page 1 0 970 720 iA
@ports
port 19 GND_EARTH 140 290 h
port 20 GND_EARTH 200 200 h
port 59 GND_EARTH 390 220 h
port 95 GND_EARTH 200 290 h
port 96 GND_EARTH 410 310 h
@parts
part 4 c 170 250 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C1
a 0 ap 9 0 15 0 hln 100 REFDES=C1
part 5 r 220 250 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R1
a 0 ap 9 0 15 0 hln 100 REFDES=R1
part 25 r 260 330 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R2
a 0 ap 9 0 15 0 hln 100 REFDES=R2
part 2 opamp 250 250 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U1
a 0 ap 9 0 14 0 hln 100 REFDES=U1
part 64 c 410 260 v
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C3
a 0 ap 9 0 15 0 hln 100 REFDES=C3
part 60 r 390 270 u
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R5
a 0 ap 9 0 15 0 hln 100 REFDES=R5
part 13 vac 140 250 h
a 0 sp 0 0 0 50 hln 100 PART=vac
a 0 a 0:13 0 0 0 hln 100 PKGREF=V1
a 1 ap 9 0 20 10 hcn 100 REFDES=V1
a 0 u 13 0 -9 23 hcn 100 ACMAG=10V
part 26 r 470 350 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R3
a 0 ap 9 0 15 0 hln 100 REFDES=R3
part 3 opamp 460 270 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U2
a 0 ap 9 0 14 0 hln 100 REFDES=U2
part 93 r 200 290 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R7
a 0 ap 9 0 15 0 hln 100 REFDES=R7
part 94 r 410 310 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R8
a 0 ap 9 0 15 0 hln 100 REFDES=R8
part 1 titleblk 970 720 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 300 95 hrn 100 PAGENO=1
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
part 90 nodeMarker 560 290 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=1
@conn
w 8
s 200 250 220 250 7
s 220 250 250 250 11
w 16
s 140 250 170 250 15
w 22
s 200 200 220 200 21
s 220 200 220 210 23
w 54
s 410 220 410 230 55
s 390 220 410 220 53
w 78
s 410 270 410 260 72
s 410 270 460 270 77
s 410 270 390 270 62
w 34
s 300 330 340 330 33
s 340 330 340 270 35
s 340 270 330 270 37
s 340 270 350 270 87
w 46
s 560 290 540 290 49
s 560 350 560 290 47
s 510 350 560 350 45
w 28
s 250 290 240 290 27
s 240 290 240 330 29
s 240 330 260 330 31
w 40
s 450 350 470 350 43
s 460 310 450 310 39
s 450 310 450 350 41
@junction
j 200 250
+ p 4 2
+ w 8
j 250 250
+ p 2 +
+ w 8
j 220 250
+ p 5 1
+ w 8
j 140 250
+ p 13 +
+ w 16
j 170 250
+ p 4 1
+ w 16
j 140 290
+ s 19
+ p 13 -
j 200 200
+ s 20
+ w 22
j 220 210
+ p 5 2
+ w 22
j 250 290
+ p 2 -
+ w 28
j 260 330
+ p 25 1
+ w 28
j 300 330
+ p 25 2
+ w 34
j 330 270
+ p 2 OUT
+ w 34
j 410 230
+ p 64 2
+ w 54
j 390 220
+ s 59
+ w 54
j 410 260
+ p 64 1
+ w 78
j 460 270
+ p 3 +
+ w 78
j 540 290
+ p 3 OUT
+ w 46
j 510 350
+ p 26 2
+ w 46
j 390 270
+ p 60 1
+ w 78
j 410 270
+ w 78
+ w 78
j 350 270
+ p 60 2
+ w 34
j 340 270
+ w 34
+ w 34
j 560 290
+ p 90 pin1
+ w 46
j 470 350
+ p 26 1
+ w 40
j 460 310
+ p 3 -
+ w 40
j 240 290
+ p 93 2
+ w 28
j 450 310
+ p 94 2
+ w 40
j 200 290
+ s 95
+ p 93 1
j 410 310
+ s 96
+ p 94 1
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
