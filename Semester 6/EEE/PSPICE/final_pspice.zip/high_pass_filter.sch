*version 9.1 2512707985
u 213
V? 4
R? 15
C? 7
U? 5
? 3
@libraries
@analysis
.AC 1 3 0
+0 101
+1 10
+2 10000k
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 10540 
@status
n 0 126:05:10:10:30:07;1781112607 e 
s 2832 126:05:10:12:36:55;1781120215 e 
*page 1 0 970 720 iA
@ports
port 74 GND_EARTH 220 330 h
port 75 GND_EARTH 270 430 h
port 101 GND_EARTH 500 350 h
port 102 GND_EARTH 550 450 h
port 73 GND_EARTH 80 470 h
port 6 GND_EARTH 80 240 h
port 17 GND_EARTH 170 110 h
port 34 GND_EARTH 220 210 h
port 152 GND_EARTH 440 240 h
port 154 GND_EARTH 580 210 h
port 153 GND_EARTH 530 110 h
@parts
part 70 r 270 430 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R6
a 0 ap 9 0 15 0 hln 100 REFDES=R6
part 96 r 530 410 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R7
a 0 ap 9 0 15 0 hln 100 REFDES=R7
part 98 r 610 500 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R8
a 0 ap 9 0 15 0 hln 100 REFDES=R8
part 99 r 550 450 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R9
a 0 ap 9 0 15 0 hln 100 REFDES=R9
part 67 r 250 390 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R4
a 0 ap 9 0 15 0 hln 100 REFDES=R4
part 72 vac 80 420 h
a 0 sp 0 0 0 50 hln 100 PART=vac
a 0 u 13 0 -9 23 hcn 100 ACMAG=10V
a 0 a 0:13 0 0 0 hln 100 PKGREF=V2
a 1 ap 9 0 20 10 hcn 100 REFDES=V2
part 118 c 110 390 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C4
a 0 ap 9 0 15 0 hln 100 REFDES=C4
part 66 c 190 390 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C2
a 0 ap 9 0 15 0 hln 100 REFDES=C2
part 130 r 330 510 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R10
a 0 ap 9 0 15 0 hln 100 REFDES=R10
part 69 r 330 480 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R5
a 0 ap 9 0 15 0 hln 100 REFDES=R5
part 71 opamp 320 390 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U2
a 0 ap 9 0 14 0 hln 100 REFDES=U2
part 95 c 450 410 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C3
a 0 ap 9 0 15 0 hln 100 REFDES=C3
part 4 c 120 170 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C1
a 0 ap 9 0 15 0 hln 100 REFDES=C1
part 3 r 200 170 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R1
a 0 ap 9 0 15 0 hln 100 REFDES=R1
part 22 r 280 260 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R2
a 0 ap 9 0 15 0 hln 100 REFDES=R2
part 33 r 220 210 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R3
a 0 ap 9 0 15 0 hln 100 REFDES=R3
part 2 vac 80 190 h
a 0 sp 0 0 0 50 hln 100 PART=vac
a 0 a 0:13 0 0 0 hln 100 PKGREF=V1
a 1 ap 9 0 20 10 hcn 100 REFDES=V1
a 0 u 13 0 -9 23 hcn 100 ACMAG=10V
part 149 r 580 210 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R13
a 0 ap 9 0 15 0 hln 100 REFDES=R13
part 147 r 610 170 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R11
a 0 ap 9 0 15 0 hln 100 REFDES=R11
part 150 vac 440 190 h
a 0 sp 0 0 0 50 hln 100 PART=vac
a 0 u 13 0 -9 23 hcn 100 ACMAG=10V
a 0 a 0:13 0 0 0 hln 100 PKGREF=V3
a 1 ap 9 0 20 10 hcn 100 REFDES=V3
part 187 c 470 170 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C6
a 0 ap 9 0 15 0 hln 100 REFDES=C6
part 146 c 540 170 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C5
a 0 ap 9 0 15 0 hln 100 REFDES=C5
part 202 r 640 290 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R14
a 0 ap 9 0 15 0 hln 100 REFDES=R14
part 148 r 640 260 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R12
a 0 ap 9 0 15 0 hln 100 REFDES=R12
part 100 opamp 600 410 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U3
a 0 ap 9 0 14 0 hln 100 REFDES=U3
part 151 opamp 630 170 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U4
a 0 ap 9 0 14 0 hln 100 REFDES=U4
part 5 opamp 270 170 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U1
a 0 ap 9 0 14 0 hln 100 REFDES=U1
part 1 titleblk 970 720 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
a 1 s 13 0 300 95 hrn 100 PAGENO=1
part 103 nodeMarker 350 190 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=U3:OUT
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=1
@conn
w 47
a 0 up 0:33 0 0 0 hln 100 V=
s 310 480 330 480 46
s 310 430 310 480 48
a 0 up 33 0 312 455 hlt 100 V=
s 320 430 310 430 50
w 53
a 0 up 0:33 0 0 0 hln 100 V=
s 250 330 250 350 52
s 220 330 250 330 54
a 0 up 33 0 235 329 hct 100 V=
w 82
a 0 up 0:33 0 0 0 hln 100 V=
s 590 500 610 500 81
s 590 450 590 500 83
a 0 up 33 0 592 475 hlt 100 V=
s 600 450 590 450 85
w 88
a 0 up 0:33 0 0 0 hln 100 V=
s 530 350 530 370 87
s 500 350 530 350 89
a 0 up 33 0 515 349 hct 100 V=
w 92
a 0 up 0:33 0 0 0 hln 100 V=
s 480 410 530 410 93
a 0 up 33 0 565 409 hct 100 V=
s 530 410 600 410 97
a 0 up 33 0 565 409 hct 100 V=
w 57
a 0 up 0:33 0 0 0 hln 100 V=
s 250 390 320 390 68
a 0 up 33 0 285 389 hct 100 V=
s 220 390 250 390 58
a 0 up 33 0 295 389 hct 100 V=
w 65
a 0 up 0:33 0 0 0 hln 100 V=
s 80 470 80 460 64
a 0 up 33 0 82 465 hlt 100 V=
w 61
a 0 up 0:33 0 0 0 hln 100 V=
s 80 390 80 420 120
s 110 390 80 390 119
a 0 up 33 0 95 389 hct 100 V=
w 128
a 0 up 0:33 0 0 0 hln 100 V=
s 140 390 170 390 126
s 170 390 190 390 133
s 170 390 170 510 131
s 170 510 330 510 134
a 0 up 33 0 250 509 hct 100 V=
w 137
a 0 up 0:33 0 0 0 hln 100 V=
s 370 510 400 510 136
s 400 480 400 410 42
a 0 up 33 0 402 445 hlt 100 V=
s 370 480 400 480 44
s 450 410 400 410 109
s 400 510 400 480 138
w 8
a 0 up 0:33 0 0 0 hln 100 V=
s 80 240 80 230 7
a 0 up 33 0 82 235 hlt 100 V=
w 10
a 0 up 0:33 0 0 0 hln 100 V=
s 80 190 80 170 9
s 80 170 120 170 11
a 0 up 33 0 100 169 hct 100 V=
w 14
a 0 up 0:33 0 0 0 hln 100 V=
s 150 170 200 170 13
s 200 170 270 170 15
a 0 up 33 0 235 169 hct 100 V=
w 19
a 0 up 0:33 0 0 0 hln 100 V=
s 170 110 200 110 18
a 0 up 33 0 185 109 hct 100 V=
s 200 110 200 130 20
w 24
a 0 up 0:33 0 0 0 hln 100 V=
s 270 210 260 210 23
s 260 210 260 260 25
a 0 up 33 0 262 235 hlt 100 V=
s 260 260 280 260 27
w 160
a 0 up 0:33 0 0 0 hln 100 V=
s 440 240 440 230 159
a 0 up 33 0 442 235 hlt 100 V=
w 174
a 0 up 0:33 0 0 0 hln 100 V=
s 630 210 620 210 173
s 620 210 620 260 175
a 0 up 33 0 622 235 hlt 100 V=
s 620 260 640 260 177
w 170
a 0 up 0:33 0 0 0 hln 100 V=
s 610 110 610 130 171
s 530 110 610 110 169
a 0 up 33 0 570 109 hct 100 V=
w 166
a 0 up 0:33 0 0 0 hln 100 V=
s 610 170 630 170 182
s 570 170 610 170 165
a 0 up 33 0 615 169 hct 100 V=
w 162
a 0 up 0:33 0 0 0 hln 100 V=
s 440 170 440 190 189
s 470 170 440 170 188
a 0 up 33 0 455 169 hct 100 V=
w 196
a 0 up 0:33 0 0 0 hln 100 V=
s 500 170 520 170 199
s 520 170 540 170 205
s 520 170 520 290 203
s 520 290 640 290 206
a 0 up 33 0 580 289 hct 100 V=
w 78
a 0 up 0:33 0 0 0 hln 100 V=
s 680 500 680 430 77
a 0 up 33 0 682 465 hlt 100 V=
s 650 500 680 500 79
w 209
a 0 up 0:33 0 0 0 hln 100 V=
s 680 290 710 290 208
s 680 260 710 260 155
s 710 260 710 190 157
a 0 up 33 0 712 225 hlt 100 V=
s 710 290 710 260 210
w 30
a 0 up 0:33 0 0 0 hln 100 V=
s 320 260 350 260 29
s 350 260 350 190 31
a 0 up 33 0 352 225 hlt 100 V=
@junction
j 250 350
+ p 67 2
+ w 53
j 250 390
+ p 67 1
+ w 57
j 330 480
+ p 69 1
+ w 47
j 310 430
+ p 70 2
+ w 47
j 320 430
+ p 71 -
+ w 47
j 320 390
+ p 71 +
+ w 57
j 220 330
+ s 74
+ w 53
j 270 430
+ s 75
+ p 70 1
j 550 450
+ p 99 1
+ s 102
j 680 430
+ p 100 OUT
+ w 78
j 650 500
+ p 98 2
+ w 78
j 610 500
+ p 98 1
+ w 82
j 590 450
+ p 99 2
+ w 82
j 600 450
+ p 100 -
+ w 82
j 530 370
+ p 96 2
+ w 88
j 500 350
+ s 101
+ w 88
j 480 410
+ p 95 2
+ w 92
j 530 410
+ p 96 1
+ w 92
j 600 410
+ p 100 +
+ w 92
j 220 390
+ p 66 2
+ w 57
j 80 460
+ p 72 -
+ w 65
j 80 470
+ s 73
+ w 65
j 80 420
+ p 72 +
+ w 61
j 110 390
+ p 118 1
+ w 61
j 140 390
+ p 118 2
+ w 128
j 190 390
+ p 66 1
+ w 128
j 170 390
+ w 128
+ w 128
j 330 510
+ p 130 1
+ w 128
j 370 510
+ p 130 2
+ w 137
j 370 480
+ p 69 2
+ w 137
j 400 410
+ p 71 OUT
+ w 137
j 450 410
+ p 95 1
+ w 137
j 400 480
+ w 137
+ w 137
j 220 210
+ p 33 1
+ s 34
j 320 260
+ p 22 2
+ w 30
j 350 190
+ p 5 OUT
+ w 30
j 80 230
+ p 2 -
+ w 8
j 80 240
+ s 6
+ w 8
j 80 190
+ p 2 +
+ w 10
j 120 170
+ p 4 1
+ w 10
j 150 170
+ p 4 2
+ w 14
j 200 170
+ p 3 1
+ w 14
j 270 170
+ p 5 +
+ w 14
j 170 110
+ s 17
+ w 19
j 200 130
+ p 3 2
+ w 19
j 260 210
+ p 33 2
+ w 24
j 270 210
+ p 5 -
+ w 24
j 280 260
+ p 22 1
+ w 24
j 580 210
+ s 154
+ p 149 1
j 440 230
+ p 150 -
+ w 160
j 440 240
+ s 152
+ w 160
j 630 170
+ p 151 +
+ w 166
j 620 210
+ p 149 2
+ w 174
j 630 210
+ p 151 -
+ w 174
j 640 260
+ p 148 1
+ w 174
j 610 170
+ p 147 1
+ w 166
j 610 130
+ p 147 2
+ w 170
j 530 110
+ s 153
+ w 170
j 570 170
+ p 146 2
+ w 166
j 440 190
+ p 150 +
+ w 162
j 470 170
+ p 187 1
+ w 162
j 500 170
+ p 187 2
+ w 196
j 540 170
+ p 146 1
+ w 196
j 520 170
+ w 196
+ w 196
j 640 290
+ p 202 1
+ w 196
j 680 290
+ p 202 2
+ w 209
j 680 260
+ p 148 2
+ w 209
j 710 190
+ p 151 OUT
+ w 209
j 710 260
+ w 209
+ w 209
j 350 190
+ p 103 pin1
+ p 5 OUT
j 350 190
+ p 103 pin1
+ w 30
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
