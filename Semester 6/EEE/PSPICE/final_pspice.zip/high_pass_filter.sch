*version 9.1 900211866
u 36
V? 2
R? 4
C? 2
U? 2
? 2
@libraries
@analysis
.AC 1 3 0
+0 101
+1 10
+2 100k
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 2656 
@status
n 0 126:05:09:12:30:00;1781033400 e 
s 2832 126:05:09:12:30:02;1781033402 e 
*page 1 0 970 720 iA
@ports
port 6 GND_EARTH 200 380 h
port 17 GND_EARTH 290 250 h
port 34 GND_EARTH 340 350 h
@parts
part 4 c 240 310 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C1
a 0 ap 9 0 15 0 hln 100 REFDES=C1
part 3 r 320 310 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R1
a 0 ap 9 0 15 0 hln 100 REFDES=R1
part 22 r 400 400 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R2
a 0 ap 9 0 15 0 hln 100 REFDES=R2
part 33 r 340 350 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R3
a 0 ap 9 0 15 0 hln 100 REFDES=R3
part 5 opamp 390 310 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U1
a 0 ap 9 0 14 0 hln 100 REFDES=U1
part 2 vac 200 330 h
a 0 sp 0 0 0 50 hln 100 PART=vac
a 0 a 0:13 0 0 0 hln 100 PKGREF=V1
a 1 ap 9 0 20 10 hcn 100 REFDES=V1
a 0 u 13 0 -9 23 hcn 100 ACMAG=10V
part 1 titleblk 970 720 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 300 95 hrn 100 PAGENO=1
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
part 35 nodeMarker 470 330 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=1
@conn
w 8
a 0 up 0:33 0 0 0 hln 100 V=
s 200 380 200 370 7
a 0 up 33 0 202 375 hlt 100 V=
w 10
a 0 up 0:33 0 0 0 hln 100 V=
s 200 330 200 310 9
s 200 310 240 310 11
a 0 up 33 0 220 309 hct 100 V=
w 14
a 0 up 0:33 0 0 0 hln 100 V=
s 270 310 320 310 13
s 320 310 390 310 15
a 0 up 33 0 355 309 hct 100 V=
w 19
s 290 250 320 250 18
s 320 250 320 270 20
w 24
a 0 up 0:33 0 0 0 hln 100 V=
s 390 350 380 350 23
s 380 350 380 400 25
a 0 up 33 0 382 375 hlt 100 V=
s 380 400 400 400 27
w 30
a 0 up 0:33 0 0 0 hln 100 V=
s 440 400 470 400 29
s 470 400 470 330 31
a 0 up 33 0 472 365 hlt 100 V=
@junction
j 200 370
+ p 2 -
+ w 8
j 200 380
+ s 6
+ w 8
j 200 330
+ p 2 +
+ w 10
j 240 310
+ p 4 1
+ w 10
j 320 310
+ p 3 1
+ w 14
j 270 310
+ p 4 2
+ w 14
j 390 310
+ p 5 +
+ w 14
j 290 250
+ s 17
+ w 19
j 320 270
+ p 3 2
+ w 19
j 390 350
+ p 5 -
+ w 24
j 400 400
+ p 22 1
+ w 24
j 440 400
+ p 22 2
+ w 30
j 470 330
+ p 5 OUT
+ w 30
j 380 350
+ p 33 2
+ w 24
j 340 350
+ s 34
+ p 33 1
j 470 330
+ p 35 pin1
+ p 5 OUT
j 470 330
+ p 35 pin1
+ w 30
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
