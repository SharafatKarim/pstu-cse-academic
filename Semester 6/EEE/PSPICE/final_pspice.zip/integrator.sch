*version 9.1 678180016
u 67
V? 3
U? 3
R? 4
C? 4
? 5
@libraries
@analysis
.TRAN 1 0 0 0
+0 0ns
+1 2.5s
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 3411 
@status
n 0 126:05:09:06:01:41;1781010101 e 
s 0 126:05:09:06:01:44;1781010104 e 
*page 1 0 970 720 iA
@ports
port 6 GND_EARTH 210 170 h
port 5 GND_EARTH 80 210 h
port 51 GND_EARTH 190 340 h
port 52 GND_EARTH 60 380 h
@parts
part 19 c 220 240 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C1
a 0 ap 9 0 15 0 hln 100 REFDES=C1
part 4 r 130 210 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R1
a 0 ap 9 0 15 0 hln 100 REFDES=R1
part 2 vsin 90 210 v
a 0 a 0:13 0 0 0 hln 100 PKGREF=V1
a 1 ap 9 0 20 10 hcn 100 REFDES=V1
a 1 u 0 0 0 0 hcn 100 VOFF=0
a 1 u 0 0 0 0 hcn 100 VAMPL=10
a 1 u 0 0 0 0 hcn 100 FREQ=4
part 3 opamp 210 170 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U1
a 0 ap 9 0 14 0 hln 100 REFDES=U1
part 61 c 120 380 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C3
a 0 ap 9 0 15 0 hln 100 REFDES=C3
part 60 r 200 410 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R3
a 0 ap 9 0 15 0 hln 100 REFDES=R3
part 49 vsin 70 380 v
a 1 u 0 0 0 0 hcn 100 VOFF=0
a 1 u 0 0 0 0 hcn 100 VAMPL=10
a 1 u 0 0 0 0 hcn 100 FREQ=4
a 0 a 0:13 0 0 0 hln 100 PKGREF=V2
a 1 ap 9 0 20 10 hcn 100 REFDES=V2
part 50 opamp 190 340 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U2
a 0 ap 9 0 14 0 hln 100 REFDES=U2
part 1 titleblk 970 720 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
a 1 s 13 0 300 95 hrn 100 PAGENO=1
part 65 nodeMarker 110 380 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=3
part 66 nodeMarker 270 360 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=4
@conn
w 8
a 0 up 0:33 0 0 0 hln 100 V=
s 90 210 80 210 7
a 0 up 33 0 85 209 hct 100 V=
w 25
a 0 up 0:33 0 0 0 hln 100 V=
s 220 240 200 240 24
s 170 210 200 210 17
s 200 210 210 210 28
s 200 240 200 210 26
a 0 up 33 0 202 225 hlt 100 V=
w 21
a 0 up 0:33 0 0 0 hln 100 V=
s 290 190 290 240 20
a 0 up 33 0 292 215 hlt 100 V=
s 290 240 250 240 22
w 33
s 70 380 60 380 32
a 0 up 33 0 65 379 hct 100 V=
w 35
s 200 410 180 410 34
s 150 380 180 380 38
s 180 380 190 380 42
s 180 410 180 380 40
a 0 up 33 0 182 395 hlt 100 V=
w 63
s 120 380 110 380 62
w 44
s 270 360 270 410 43
a 0 up 33 0 272 385 hlt 100 V=
s 270 410 240 410 45
s 240 410 230 410 64
@junction
j 210 170
+ s 6
+ p 3 +
j 90 210
+ p 2 +
+ w 8
j 80 210
+ s 5
+ w 8
j 130 210
+ p 4 1
+ p 2 -
j 290 190
+ p 3 OUT
+ w 21
j 250 240
+ p 19 2
+ w 21
j 220 240
+ p 19 1
+ w 25
j 170 210
+ p 4 2
+ w 25
j 210 210
+ p 3 -
+ w 25
j 200 210
+ w 25
+ w 25
j 270 360
+ p 50 OUT
+ w 44
j 190 340
+ s 51
+ p 50 +
j 60 380
+ s 52
+ w 33
j 70 380
+ p 49 +
+ w 33
j 180 380
+ w 35
+ w 35
j 190 380
+ p 50 -
+ w 35
j 150 380
+ p 61 2
+ w 35
j 120 380
+ p 61 1
+ w 63
j 110 380
+ p 49 -
+ w 63
j 240 410
+ p 60 2
+ w 44
j 200 410
+ p 60 1
+ w 35
j 110 380
+ p 65 pin1
+ p 49 -
j 110 380
+ p 65 pin1
+ w 63
j 270 360
+ p 66 pin1
+ p 50 OUT
j 270 360
+ p 66 pin1
+ w 44
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
