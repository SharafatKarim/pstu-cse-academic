* Schematics Aliases *

.ALIASES
R_R1            R1(1=$N_0002 2=$N_0001 )
E_U1            U1(OUT=$N_0001 +=0 -=$N_0002 )
V_V1            V1(+=0 -=$N_0003 )
C_C1            C1(1=$N_0003 2=$N_0002 )
.ENDALIASES

