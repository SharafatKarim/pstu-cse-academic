* Schematics Aliases *

.ALIASES
R_R3            R3(1=$N_0002 2=$N_0001 )
R_R5            R5(1=0 2=$N_0002 )
E_U2            U2(OUT=$N_0001 +=$N_0003 -=$N_0002 )
R_R6            R6(1=$N_0004 2=$N_0003 )
C_C2            C2(1=$N_0003 2=0 )
V_V3            V3(+=$N_0004 -=0 )
.ENDALIASES

