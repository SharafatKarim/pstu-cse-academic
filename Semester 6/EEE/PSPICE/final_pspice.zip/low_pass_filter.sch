*version 9.1 4146787149
u 83
V? 4
R? 7
C? 3
U? 3
? 5
@libraries
@analysis
.AC 1 3 0
+0 101
+1 10
+2 100k
.TRAN 0 0 0 0
+0 0
+1 1
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 2671 
@status
n 0 126:05:09:12:27:03;1781033223 e 
s 0 126:05:09:12:27:07;1781033227 e 
*page 1 0 970 720 iA
@ports
port 61 GND_EARTH 250 310 h
port 75 GND_EARTH 260 230 h
port 41 GND_EARTH 210 310 h
@parts
part 38 r 340 340 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R3
a 0 ap 9 0 15 0 hln 100 REFDES=R3
part 58 r 250 310 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R5
a 0 ap 9 0 15 0 hln 100 REFDES=R5
part 37 opamp 310 270 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U2
a 0 ap 9 0 14 0 hln 100 REFDES=U2
part 64 r 220 270 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R6
a 0 ap 9 0 15 0 hln 100 REFDES=R6
part 67 c 280 270 v
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C2
a 0 ap 9 0 15 0 hln 100 REFDES=C2
part 82 vac 210 270 h
a 0 sp 0 0 0 50 hln 100 PART=vac
a 0 a 0:13 0 0 0 hln 100 PKGREF=V3
a 1 ap 9 0 20 10 hcn 100 REFDES=V3
a 0 u 13 0 -9 23 hcn 100 ACMAG=10V
part 1 titleblk 970 720 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
a 1 s 13 0 300 95 hrn 100 PAGENO=1
part 81 nodeMarker 400 290 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=4
@conn
w 47
a 0 up 0:33 0 0 0 hln 100 V=
s 310 310 300 310 46
s 300 310 300 340 48
s 300 340 340 340 50
a 0 up 33 0 320 339 hct 100 V=
s 300 310 290 310 59
w 70
a 0 up 0:33 0 0 0 hln 100 V=
s 260 270 280 270 69
s 280 270 310 270 73
a 0 up 33 0 295 269 hct 100 V=
w 77
a 0 up 0:33 0 0 0 hln 100 V=
s 280 240 280 230 76
s 280 230 260 230 78
a 0 up 33 0 270 229 hct 100 V=
w 53
a 0 up 0:33 0 0 0 hln 100 V=
s 380 340 400 340 52
s 400 340 400 290 54
a 0 up 33 0 402 315 hlt 100 V=
s 400 290 390 290 56
w 66
a 0 up 0:33 0 0 0 hln 100 V=
s 220 270 210 270 65
a 0 up 33 0 215 269 hct 100 V=
@junction
j 310 310
+ p 37 -
+ w 47
j 340 340
+ p 38 1
+ w 47
j 380 340
+ p 38 2
+ w 53
j 390 290
+ p 37 OUT
+ w 53
j 290 310
+ p 58 2
+ w 47
j 300 310
+ w 47
+ w 47
j 250 310
+ s 61
+ p 58 1
j 220 270
+ p 64 1
+ w 66
j 260 270
+ p 64 2
+ w 70
j 310 270
+ p 37 +
+ w 70
j 280 270
+ p 67 1
+ w 70
j 280 240
+ p 67 2
+ w 77
j 260 230
+ s 75
+ w 77
j 400 290
+ p 81 pin1
+ w 53
j 210 310
+ p 82 -
+ s 41
j 210 270
+ p 82 +
+ w 66
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
