*version 9.1 1348163224
u 230
V? 7
R? 18
C? 8
U? 6
? 9
@libraries
@analysis
.AC 1 3 0
+0 101
+1 10
+2 100k
.TRAN 0 0 0 0
+0 0
+1 1
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 10317 
@status
n 0 126:05:10:10:34:58;1781112898 e 
s 2832 126:05:11:06:26:45;1781184405 e 
*page 1 0 970 720 iA
@ports
port 61 GND_EARTH 140 170 h
port 75 GND_EARTH 150 90 h
port 41 GND_EARTH 100 170 h
port 96 GND_EARTH 470 180 h
port 97 GND_EARTH 480 100 h
port 98 GND_EARTH 370 180 h
port 187 GND_EARTH 210 390 h
port 188 GND_EARTH 220 310 h
port 189 GND_EARTH 110 390 h
port 221 GND_EARTH 430 410 h
port 222 GND_EARTH 440 330 h
@parts
part 38 r 230 200 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R3
a 0 ap 9 0 15 0 hln 100 REFDES=R3
part 58 r 140 170 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R5
a 0 ap 9 0 15 0 hln 100 REFDES=R5
part 37 opamp 200 130 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U2
a 0 ap 9 0 14 0 hln 100 REFDES=U2
part 64 r 110 130 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R6
a 0 ap 9 0 15 0 hln 100 REFDES=R6
part 67 c 170 130 v
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C2
a 0 ap 9 0 15 0 hln 100 REFDES=C2
part 82 vac 100 130 h
a 0 sp 0 0 0 50 hln 100 PART=vac
a 0 a 0:13 0 0 0 hln 100 PKGREF=V3
a 1 ap 9 0 20 10 hcn 100 REFDES=V3
a 0 u 13 0 -9 23 hcn 100 ACMAG=10V
part 91 r 470 180 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R8
a 0 ap 9 0 15 0 hln 100 REFDES=R8
part 95 vac 370 140 h
a 0 sp 0 0 0 50 hln 100 PART=vac
a 0 u 13 0 -9 23 hcn 100 ACMAG=10V
a 0 a 0:13 0 0 0 hln 100 PKGREF=V4
a 1 ap 9 0 20 10 hcn 100 REFDES=V4
part 93 r 430 140 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R9
a 0 ap 9 0 15 0 hln 100 REFDES=R9
part 124 r 370 140 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R10
a 0 ap 9 0 15 0 hln 100 REFDES=R10
part 94 c 500 140 v
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C3
a 0 ap 9 0 15 0 hln 100 REFDES=C3
part 92 opamp 530 140 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U3
a 0 ap 9 0 14 0 hln 100 REFDES=U3
part 90 r 560 210 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R7
a 0 ap 9 0 15 0 hln 100 REFDES=R7
a 0 u 13 0 15 25 hln 100 VALUE=2k
part 131 c 590 240 u
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C4
a 0 ap 9 0 15 0 hln 100 REFDES=C4
a 0 u 13 0 15 25 hln 100 VALUE=1
part 178 r 210 390 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R11
a 0 ap 9 0 15 0 hln 100 REFDES=R11
part 179 vac 110 350 h
a 0 sp 0 0 0 50 hln 100 PART=vac
a 0 u 13 0 -9 23 hcn 100 ACMAG=10V
a 0 a 0:13 0 0 0 hln 100 PKGREF=V5
a 1 ap 9 0 20 10 hcn 100 REFDES=V5
part 180 r 170 350 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R12
a 0 ap 9 0 15 0 hln 100 REFDES=R12
part 181 r 110 350 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R13
a 0 ap 9 0 15 0 hln 100 REFDES=R13
part 182 c 240 350 v
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C5
a 0 ap 9 0 15 0 hln 100 REFDES=C5
part 184 opamp 270 350 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U4
a 0 ap 9 0 14 0 hln 100 REFDES=U4
part 185 r 300 420 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=2k
a 0 a 0:13 0 0 0 hln 100 PKGREF=R14
a 0 ap 9 0 15 0 hln 100 REFDES=R14
part 186 c 330 450 u
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=1
a 0 a 0:13 0 0 0 hln 100 PKGREF=C6
a 0 ap 9 0 15 0 hln 100 REFDES=C6
part 214 r 520 440 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R15
a 0 ap 9 0 15 0 hln 100 REFDES=R15
part 215 r 430 410 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R16
a 0 ap 9 0 15 0 hln 100 REFDES=R16
part 216 opamp 490 370 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U5
a 0 ap 9 0 14 0 hln 100 REFDES=U5
part 217 r 390 370 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R17
a 0 ap 9 0 15 0 hln 100 REFDES=R17
part 218 c 460 370 v
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C7
a 0 ap 9 0 15 0 hln 100 REFDES=C7
part 1 titleblk 970 720 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
a 1 s 13 0 300 95 hrn 100 PAGENO=1
part 229 nodeMarker 290 150 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=8
@conn
w 66
a 0 up 0:33 0 0 0 hln 100 V=
s 110 130 100 130 65
a 0 up 33 0 105 129 hct 100 V=
w 77
a 0 up 0:33 0 0 0 hln 100 V=
s 170 90 150 90 78
a 0 up 33 0 160 89 hct 100 V=
s 170 100 170 90 76
w 70
a 0 up 0:33 0 0 0 hln 100 V=
s 170 130 200 130 73
a 0 up 33 0 185 129 hct 100 V=
s 150 130 170 130 69
w 47
a 0 up 0:33 0 0 0 hln 100 V=
s 190 170 180 170 59
s 190 200 230 200 50
a 0 up 33 0 210 199 hct 100 V=
s 190 170 190 200 48
s 200 170 190 170 46
w 109
s 500 100 480 100 108
a 0 up 33 0 490 99 hct 100 V=
s 500 110 500 100 110
w 117
a 0 up 0:33 0 0 0 hln 100 V=
s 520 180 510 180 116
s 520 210 560 210 118
a 0 up 33 0 540 209 hct 100 V=
s 520 180 520 210 120
s 530 180 520 180 122
w 113
a 0 up 0:33 0 0 0 hln 100 V=
s 500 140 530 140 112
a 0 up 33 0 515 139 hct 100 V=
s 470 140 500 140 114
a 0 up 33 0 485 139 hct 100 V=
w 129
a 0 up 0:33 0 0 0 hln 100 V=
s 430 140 420 140 127
s 420 140 410 140 134
s 420 140 420 240 132
s 420 240 560 240 135
a 0 up 33 0 490 239 hct 100 V=
w 138
a 0 up 0:33 0 0 0 hln 100 V=
s 590 240 620 240 137
s 620 160 610 160 102
s 620 210 620 160 104
a 0 up 33 0 622 185 hlt 100 V=
s 600 210 620 210 106
s 620 240 620 210 139
w 144
a 0 up 0:33 0 0 0 hln 100 V=
s 240 310 220 310 143
a 0 up 33 0 230 309 hct 100 V=
s 240 320 240 310 145
w 148
a 0 up 0:33 0 0 0 hln 100 V=
s 260 390 250 390 147
s 260 420 300 420 149
a 0 up 33 0 280 419 hct 100 V=
s 260 390 260 420 151
s 270 390 260 390 153
w 156
a 0 up 0:33 0 0 0 hln 100 V=
s 210 350 240 350 157
a 0 up 33 0 225 349 hct 100 V=
s 240 350 270 350 183
a 0 up 33 0 255 349 hct 100 V=
w 160
a 0 up 0:33 0 0 0 hln 100 V=
s 170 350 160 350 161
s 160 350 150 350 165
s 160 350 160 450 163
s 160 450 300 450 166
a 0 up 33 0 230 449 hct 100 V=
w 193
a 0 up 0:33 0 0 0 hln 100 V=
s 460 330 440 330 192
a 0 up 33 0 450 329 hct 100 V=
s 460 340 460 330 194
w 201
a 0 up 0:33 0 0 0 hln 100 V=
s 480 410 470 410 200
s 480 440 520 440 202
a 0 up 33 0 500 439 hct 100 V=
s 480 410 480 440 204
s 490 410 480 410 206
w 197
a 0 up 0:33 0 0 0 hln 100 V=
s 460 370 490 370 219
s 430 370 460 370 198
a 0 up 33 0 470 369 hct 100 V=
w 169
a 0 up 0:33 0 0 0 hln 100 V=
s 330 450 360 450 168
s 360 370 350 370 170
s 360 420 360 370 172
a 0 up 33 0 362 395 hlt 100 V=
s 340 420 360 420 174
s 360 450 360 420 176
s 360 370 390 370 225
w 209
a 0 up 0:33 0 0 0 hln 100 V=
s 580 390 570 390 208
s 580 440 580 390 210
a 0 up 33 0 582 415 hlt 100 V=
s 560 440 580 440 212
w 53
a 0 up 0:33 0 0 0 hln 100 V=
s 290 150 280 150 56
s 290 200 290 150 54
a 0 up 33 0 292 175 hlt 100 V=
s 270 200 290 200 52
@junction
j 140 170
+ p 58 1
+ s 61
j 100 170
+ p 82 -
+ s 41
j 110 130
+ p 64 1
+ w 66
j 100 130
+ p 82 +
+ w 66
j 280 150
+ p 37 OUT
+ w 53
j 270 200
+ p 38 2
+ w 53
j 150 90
+ s 75
+ w 77
j 170 100
+ p 67 2
+ w 77
j 200 130
+ p 37 +
+ w 70
j 170 130
+ p 67 1
+ w 70
j 150 130
+ p 64 2
+ w 70
j 180 170
+ p 58 2
+ w 47
j 230 200
+ p 38 1
+ w 47
j 200 170
+ p 37 -
+ w 47
j 190 170
+ w 47
+ w 47
j 470 180
+ s 96
+ p 91 1
j 480 100
+ s 97
+ w 109
j 500 110
+ p 94 2
+ w 109
j 530 140
+ p 92 +
+ w 113
j 500 140
+ p 94 1
+ w 113
j 510 180
+ p 91 2
+ w 117
j 560 210
+ p 90 1
+ w 117
j 530 180
+ p 92 -
+ w 117
j 520 180
+ w 117
+ w 117
j 370 180
+ p 95 -
+ s 98
j 370 140
+ p 124 1
+ p 95 +
j 470 140
+ p 93 2
+ w 113
j 430 140
+ p 93 1
+ w 129
j 410 140
+ p 124 2
+ w 129
j 420 140
+ w 129
+ w 129
j 560 240
+ p 131 2
+ w 129
j 590 240
+ p 131 1
+ w 138
j 610 160
+ p 92 OUT
+ w 138
j 600 210
+ p 90 2
+ w 138
j 620 210
+ w 138
+ w 138
j 260 390
+ w 148
+ w 148
j 160 350
+ w 160
+ w 160
j 360 420
+ w 169
+ w 169
j 250 390
+ p 178 2
+ w 148
j 210 350
+ p 180 2
+ w 156
j 170 350
+ p 180 1
+ w 160
j 110 350
+ p 181 1
+ p 179 +
j 150 350
+ p 181 2
+ w 160
j 240 320
+ p 182 2
+ w 144
j 240 350
+ p 182 1
+ w 156
j 270 390
+ p 184 -
+ w 148
j 270 350
+ p 184 +
+ w 156
j 350 370
+ p 184 OUT
+ w 169
j 300 420
+ p 185 1
+ w 148
j 340 420
+ p 185 2
+ w 169
j 300 450
+ p 186 2
+ w 160
j 330 450
+ p 186 1
+ w 169
j 210 390
+ s 187
+ p 178 1
j 220 310
+ s 188
+ w 144
j 110 390
+ s 189
+ p 179 -
j 480 410
+ w 201
+ w 201
j 520 440
+ p 214 1
+ w 201
j 560 440
+ p 214 2
+ w 209
j 470 410
+ p 215 2
+ w 201
j 490 370
+ p 216 +
+ w 197
j 490 410
+ p 216 -
+ w 201
j 570 390
+ p 216 OUT
+ w 209
j 460 340
+ p 218 2
+ w 193
j 460 370
+ p 218 1
+ w 197
j 430 410
+ s 221
+ p 215 1
j 440 330
+ s 222
+ w 193
j 430 370
+ p 217 2
+ w 197
j 390 370
+ p 217 1
+ w 169
j 360 370
+ w 169
+ w 169
j 290 150
+ p 229 pin1
+ w 53
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
