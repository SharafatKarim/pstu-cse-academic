*version 9.1 3453022719
u 103
U? 3
R? 7
V? 3
? 3
@libraries
@analysis
.DC 0 0 0 0 1 1
.TRAN 1 0 0 0
+0 0ns
+1 1000ns
.OP 0 
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 4582 
@status
n 0 126:05:10:10:21:17;1781112077 e 
s 0 126:05:10:10:21:20;1781112080 e 
c 126:05:10:10:22:07;1781112127
*page 1 0 970 720 iA
@ports
port 16 GND_EARTH 30 270 h
port 17 GND_EARTH 270 230 h
port 12 GND_EARTH 160 280 h
port 13 GND_EARTH 390 290 h
@parts
part 15 vdc 270 190 h
a 0 sp 0 0 22 37 hln 100 PART=vdc
a 0 a 0:13 0 0 0 hln 100 PKGREF=V2
a 1 ap 9 0 24 7 hcn 100 REFDES=V2
a 1 u 13 0 -11 18 hcn 100 DC=1V
part 7 r 70 230 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R2
a 0 ap 9 0 15 0 hln 100 REFDES=R2
a 0 u 13 0 15 25 hln 100 VALUE=2k
part 8 r 70 270 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R3
a 0 ap 9 0 15 0 hln 100 REFDES=R3
a 0 u 13 0 15 25 hln 100 VALUE=5k
part 6 r 190 180 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R1
a 0 ap 9 0 15 0 hln 100 REFDES=R1
a 0 u 13 0 15 25 hln 100 VALUE=2k
part 9 r 300 190 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R4
a 0 ap 9 0 15 0 hln 100 REFDES=R4
a 0 u 13 0 15 25 hln 100 VALUE=10k
part 10 r 300 250 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R5
a 0 ap 9 0 15 0 hln 100 REFDES=R5
a 0 u 13 0 15 25 hln 100 VALUE=3k
part 11 r 410 190 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R6
a 0 ap 9 0 15 0 hln 100 REFDES=R6
a 0 u 13 0 15 25 hln 100 VALUE=30k
part 14 vdc 30 230 h
a 0 sp 0 0 22 37 hln 100 PART=vdc
a 0 a 0:13 0 0 0 hln 100 PKGREF=V1
a 1 ap 9 0 24 7 hcn 100 REFDES=V1
a 1 u 13 0 -11 18 hcn 100 DC=-1V
part 4 opamp 160 230 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U1
a 0 ap 9 0 14 0 hln 100 REFDES=U1
part 5 opamp 390 250 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U2
a 0 ap 9 0 14 0 hln 100 REFDES=U2
part 1 titleblk 970 720 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
a 1 s 13 0 300 95 hrn 100 PAGENO=1
part 93 nodeMarker 280 250 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=1
part 95 nodeMarker 480 270 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=2
@conn
w 20
a 0 up 0:33 0 0 0 hln 100 V=
s 70 230 30 230 29
a 0 up 33 0 50 229 hct 100 V=
w 63
a 0 up 0:33 0 0 0 hln 100 V=
s 270 190 300 190 62
a 0 up 33 0 285 189 hct 100 V=
w 66
a 0 up 0:33 0 0 0 hln 100 V=
s 340 190 360 190 65
s 390 250 370 250 53
s 360 250 340 250 69
s 360 190 360 250 67
s 370 250 360 250 72
s 370 250 370 190 70
a 0 up 33 0 372 220 hlt 100 V=
s 370 190 410 190 73
w 88
a 0 up 0:33 0 0 0 hln 100 V=
s 110 270 150 270 87
s 110 230 150 230 28
s 150 230 160 230 34
s 150 230 150 180 32
a 0 up 33 0 152 205 hlt 100 V=
s 150 180 190 180 35
s 150 270 150 230 89
w 38
a 0 up 0:33 0 0 0 hln 100 V=
s 230 180 250 180 37
s 250 180 250 250 39
a 0 up 33 0 252 215 hlt 100 V=
s 250 250 240 250 41
s 250 250 280 250 43
s 280 250 300 250 94
w 76
a 0 up 0:33 0 0 0 hln 100 V=
s 450 190 480 190 75
s 480 190 480 270 77
s 480 270 470 270 79
s 480 270 480 330 81
s 480 330 70 330 83
a 0 up 33 0 275 329 hct 100 V=
s 70 330 70 270 85
w 102
s 160 280 160 270 101
@junction
j 30 270
+ s 16
+ p 14 -
j 30 230
+ p 14 +
+ w 20
j 150 230
+ w 88
+ w 88
j 230 180
+ p 6 2
+ w 38
j 240 250
+ p 4 OUT
+ w 38
j 300 250
+ p 10 1
+ w 38
j 250 250
+ w 38
+ w 38
j 270 230
+ p 15 -
+ s 17
j 270 190
+ p 15 +
+ w 63
j 300 190
+ p 9 1
+ w 63
j 340 190
+ p 9 2
+ w 66
j 390 250
+ p 5 +
+ w 66
j 340 250
+ p 10 2
+ w 66
j 360 250
+ w 66
+ w 66
j 370 250
+ w 66
+ w 66
j 410 190
+ p 11 1
+ w 66
j 450 190
+ p 11 2
+ w 76
j 470 270
+ p 5 OUT
+ w 76
j 480 270
+ w 76
+ w 76
j 70 270
+ p 8 1
+ w 76
j 110 270
+ p 8 2
+ w 88
j 160 230
+ p 4 +
+ w 88
j 190 180
+ p 6 1
+ w 88
j 280 250
+ p 93 pin1
+ w 38
j 480 270
+ p 95 pin1
+ w 76
j 110 230
+ p 7 2
+ w 88
j 70 230
+ p 7 1
+ w 20
j 160 270
+ p 4 -
+ w 102
j 160 280
+ s 12
+ w 102
j 390 290
+ s 13
+ p 5 -
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
t 91 t 5 270 256 282 270 0 1
y
t 92 t 5 490 266 502 280 0 1
x
t 2 t 5 190 136 236 150 0 9
X+10*Y =3
t 3 t 5 190 146 238 160 0 10
2*x+5*y=-5
