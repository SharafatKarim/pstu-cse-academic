* Schematics Aliases *

.ALIASES
C_C1            C1(1=$N_0001 2=$N_0002 )
R_R1            R1(1=$N_0002 2=0 )
R_R2            R2(1=$N_0004 2=$N_0003 )
R_R3            R3(1=0 2=$N_0004 )
E_U1            U1(OUT=$N_0003 +=$N_0002 -=$N_0004 )
V_V1            V1(+=$N_0001 -=0 )
.ENDALIASES

