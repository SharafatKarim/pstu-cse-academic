*version 9.1 2308429103
u 127
U? 2
V? 2
R? 7
L? 4
? 4
C? 2
@libraries
@analysis
.AC 1 3 0
+0 101
+1 10
+2 10000k
.OP 0 
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 2724 
@status
n 0 126:05:10:08:41:37;1781106097 e 
s 0 126:05:10:08:41:40;1781106100 e 
*page 1 0 970 720 iA
@ports
port 50 GND_EARTH 140 390 h
port 51 GND_EARTH 270 390 h
port 123 GND_EARTH 270 290 h
@parts
part 24 r 350 440 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R2
a 0 ap 9 0 15 0 hln 100 REFDES=R2
part 45 r 280 390 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R3
a 0 ap 9 0 15 0 hln 100 REFDES=R3
part 3 vac 140 350 h
a 0 u 13 0 -9 23 hcn 100 ACMAG=10V
a 0 sp 0 0 0 50 hln 100 PART=vac
a 0 a 0:13 0 0 0 hln 100 PKGREF=V1
a 1 ap 9 0 20 10 hcn 100 REFDES=V1
part 55 r 180 350 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R5
a 0 ap 9 0 15 0 hln 100 REFDES=R5
part 89 l 300 350 v
a 0 u 13 0 15 25 hln 100 VALUE=10H
a 0 sp 0 0 0 10 hlb 100 PART=l
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=L2012C
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=L3
a 0 ap 9 0 15 0 hln 100 REFDES=L3
part 2 opamp 340 350 h
a 0 sp 11 0 50 60 hln 100 PART=opamp
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U1
a 0 ap 9 0 14 0 hln 100 REFDES=U1
part 1 titleblk 970 720 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 300 95 hrn 100 PAGENO=1
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
part 126 nodeMarker 420 370 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=3
@conn
w 28
a 0 up 0:33 0 0 0 hln 100 V=
s 330 390 340 390 27
s 330 440 330 390 26
a 0 up 33 0 332 415 hlt 100 V=
s 350 440 330 440 25
s 330 390 320 390 47
w 54
a 0 up 0:33 0 0 0 hln 100 V=
s 270 390 280 390 53
a 0 up 33 0 275 389 hct 100 V=
w 21
a 0 up 0:33 0 0 0 hln 100 V=
s 180 350 140 350 60
a 0 up 33 0 160 349 hct 100 V=
w 97
a 0 up 0:33 0 0 0 hln 100 V=
s 340 350 300 350 118
a 0 up 33 0 280 349 hct 100 V=
s 300 350 220 350 121
w 125
s 270 290 300 290 124
w 115
a 0 up 0:33 0 0 0 hln 100 V=
s 420 440 420 370 32
a 0 up 33 0 422 405 hlt 100 V=
s 390 440 420 440 31
@junction
j 340 390
+ p 2 -
+ w 28
j 420 370
+ p 2 OUT
+ w 115
j 390 440
+ p 24 2
+ w 115
j 350 440
+ p 24 1
+ w 28
j 320 390
+ p 45 2
+ w 28
j 330 390
+ w 28
+ w 28
j 140 390
+ s 50
+ p 3 -
j 280 390
+ p 45 1
+ w 54
j 270 390
+ s 51
+ w 54
j 180 350
+ p 55 1
+ w 21
j 140 350
+ p 3 +
+ w 21
j 340 350
+ p 2 +
+ w 97
j 220 350
+ p 55 2
+ w 97
j 300 350
+ p 89 1
+ w 97
j 300 290
+ p 89 2
+ w 125
j 270 290
+ s 123
+ w 125
j 420 370
+ p 126 pin1
+ p 2 OUT
j 420 370
+ p 126 pin1
+ w 115
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
