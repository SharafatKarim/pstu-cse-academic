* Schematics Aliases *

.ALIASES
R_R1            R1(1=0 2=$N_0001 )
V_V1            V1(+=0 -=$N_0002 )
E_U1            U1(OUT=$N_0001 +=$N_0002 -=$N_0001 )
.ENDALIASES

