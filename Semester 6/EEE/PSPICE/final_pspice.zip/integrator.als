* Schematics Aliases *

.ALIASES
C_C1            C1(1=$N_0001 2=$N_0002 )
R_R1            R1(1=$N_0003 2=$N_0001 )
V_V1            V1(+=0 -=$N_0003 )
E_U1            U1(OUT=$N_0002 +=0 -=$N_0001 )
C_C3            C3(1=$N_0004 2=$N_0005 )
R_R3            R3(1=$N_0005 2=$N_0006 )
V_V2            V2(+=0 -=$N_0004 )
E_U2            U2(OUT=$N_0006 +=0 -=$N_0005 )
.ENDALIASES

