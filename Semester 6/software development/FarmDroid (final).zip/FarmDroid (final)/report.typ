#set page(
  paper: "a4",
  margin: (x: 2.5cm, y: 2.5cm),
  numbering: "1",
  columns: 1,
)
// #set text(font: "Ubuntu Nerd Font")
#set text(size: 12pt)
#set par(justify: true)
#set heading(numbering: "1.")
#show bibliography: set heading(numbering: "1.")
#show figure: set block(breakable: true)

// --------------------------
// Title page
// --------------------------

#set page(numbering: none)

#align(left)[ 
  #image("PSTU.png", width: 30%, height: auto, alt: "PSTU")
  #text(21pt)[
    *Patuakhali Science and Technology University* \
  ]
  #text(18pt)[
    Faculty of Computer Science and Engineering
  ]

  #line(length: 100%)
  #align(left, text(17pt)[
    *CCE 322 :: Computer Peripheral and Interfacing Sessional*
  ])
  #align(left, text(16pt)[
    *Mid Report*
  ])
  #line(length: 100%)
]

#align(left)[
  #v(12pt)
  #image("logo/logo-2.png", width: 60%, height: auto, alt: "Divider")
]

#align(bottom)[
  #line(length: 100%)
  *Project Title : * Farm Droid \
  *Submission Date :* #datetime.today().display("[day] [month repr:long] [year]") \
  #line(length: 100%)
]

#grid(
  columns: (45%, 65%),
  gutter: 2em,
  [
    #align(left)[
      #text(size: 14pt, weight: "bold")[Submitted by,] \
      #v(0.5em)
      + *2102003* - Md. Abu Taher \
      + *2102007* - Mehedi Hasan \
      + *2102020* - Md. Sadman Kabir Bhuiyan \
      + *2102024* - Md. Sharafat Karim \
      + *2102051* - Md. Safiullah Farajy
    ]
  ],
  [
    #align(left)[
      #text(size: 14pt, weight: "bold")[Submitted to,] \
      #v(0.5em)
      + *Sarna Majumder* \
        Associate Professor, \
        Depart. of Computer and Communication Engineering, \
        Patuakhali Science and Technology University.
      + *Prof. Dr. Md Samsuzzaman* \
        Professor, \
        Depart. of Computer and Communication Engineering, \
        Patuakhali Science and Technology University.
    ]
  ],
)

#pagebreak()

// --------------------------
// Contents
// --------------------------
#set page(numbering: "1")
#outline()
#pagebreak()


#align(center)[
  #image("logo/logo.png", width: 25%, height: auto, alt: "PSTU Diary Logo")
]
#align(center)[
  #text(size: 20pt, weight: "bold")[Farm Droid] \
  #text(size: 14pt)[An Autonomous Agricultural Robot]
]
= Introduction

Agriculture is facing significant challenges due to labor shortages and the need for precision monitoring of crop health. "Farm Droid" is a prototype for a compact, autonomous agricultural robot designed to address these issues through smart automation.

Unlike traditional heavy machinery which is expensive and inflexible, Farm Droid utilizes a lightweight, terrain-adaptive mobile platform. This allows it to navigate through crop rows efficiently to perform monitoring and manipulation tasks. The system integrates modern embedded technologies, using a Raspberry Pi 4 for computer vision and decision-making, and an Arduino UNO/ nano for real-time motor control and sensor data acquisition.

= Objectives

The primary goal is to build a smart farming assistant capable of autonomous operation. The specific objectives are:

- *Environmental Monitoring:* To integrate sensors for measuring soil moisture, pH levels, and weather conditions (Rain/Temperature).
- *Robotic Manipulation:* To develop a servo-driven arm mechanism for different modular tasks like weeding.
- *Computer Vision:* To utilize a Raspberry Pi Camera and OpenCV to recognize crops, weeds, and obstacles in real-time.
- *Seamless Connectivity:* To establish reliable remote monitoring and control through telegram bot integration or a custom mobile app.
- *Autonomous Activity:* To allow the robot to perform tasks like plant seeding, watering, and soil fertilization without human intervention.
- *Adaptive Mobility:* To develop a robust locomotion system (Rover or Legged) capable of traversing uneven agricultural terrain.

= Problem Statement

Conventional heavy farming machinery is often unsuited for small-scale precision agriculture or delicate crop fields. Large tractors cause soil compaction and lack the agility to perform individual plant inspection. There is a lack of affordable, modular robotic solutions that can perform both monitoring and physical manipulation tasks in such environments. Farm Droid aims to bridge this gap by providing a lightweight, intelligent, and versatile solution.

= Scope

The project scope encompasses the mechanical assembly, circuit integration, and software development of the robot.
- *Hardware:* Custom chassis design, Motor/Servo drive system, Power distribution system.
- *Software:* Python-based vision processing, C++ based motor control firmware.
- *Limitation:* The prototype will focus on small-scale demonstration (e.g., a garden or test bed) rather than full industrial field deployment.

= Methodology

== System Architecture
We are adopting a "Distributed Computing" architecture to handle the computational load efficiently:

- *The Brain (Raspberry Pi 4):* Handles high-level logic, image processing (OpenCV), and path planning. It communicates via Serial/I2C/USB.
- *The Controller (Arduino/ESP32):* dedicated to PWM generation for the motor drivers and reading analog sensors.

== Technology Stack

- *Language*: Python (Vision/Logic), C++ (Arduino Firmware)
- *Vision*: OpenCV, TensorFlow Lite (Optional for object detection)
- *Hardware Interface*: I2C (Inter-Integrated Circuit), USB.
- *Power Management*: A 65W/22W 30000mAh with Buck Converters for system stability.

= Hardware Components

The core components for the Farm Droid include:

- *Actuators:* DC Gear Motors or MG996R Servos (Mobility), SG90 (Gripper/Arm), GA25 (Metal Gear motor).
- *Sensors:* Ultrasonic (HC-SR04), Soil Moisture, Rain Sensor, DHT11, IR (Infrared), LDR (Light Dependent Resistor), DFPlayer Mini, RFID Reader(Radio Frequency Identification), Relay, PH Electrode, Gas sensor(MQ135).
- *Controllers:* Raspberry Pi 4 Model B (4GB), Arduino Uno / Nano.
- *Drivers:* L298N/Motor Driver (for Wheels).
- *Vision:* Official Raspberry Pi Camera Module using Pi camera 5MP.
- *Power Supplier:* LM2596 Buck Converter, 65W/22W 30000mAh Power Bank.

= Budget Estimation

The following is a detailed breakdown of the estimated costs for the hardware components required for the "Farm Droid" project based on real market prices in Bangladesh. The total estimated cost for the project is approximately BDT 31488. This budget includes all necessary components for building the prototype, such as controllers, sensors, actuators, power supplies, and miscellaneous materials.

// == Mandatory Components & Modules

#figure(
  table(
    columns: (auto, 47%, 2fr, 2fr, 2fr),
    fill: (col, row) => if row == 0 { luma(230) } else { white },
    align: (left, left, center, center, right),
    [*Category*], [*Component Name*], [*Unit (BDT)*], [*Qty*], [*Total (BDT)*],

    // --- Controllers & Computing ---
    table.cell(rowspan: 2, align: left)[*Controllers*],
    [#link("https://techshopbd.com/product/raspberry-pi-4-model-b-4gb-brand-dfrobot")[Raspberry Pi 4 Model B (4GB) [1]]], [14,100], [1], [14,100],
    [#link("https://store.roboticsbd.com/development-boards/94-8-arduino-uno-r3-robotics-bangladesh.html?srsltid=AfmBOoolvCp64UrVtsHrv5x7m8bGrIMd9VrK3w-CciJUeW8Ly0NY4sGZ988")[Arduino Uno R3 [2]]], [988], [2], [1,976],
    

    // --- Actuators & Drivers ---
    table.cell(rowspan: 4, align: left)[*Motors & Drivers*],
    [#link("https://projectkitsbd.com/product/370ga25-dc6-12v-metal-gear-motors")[GA25 Metal Gear Motor [3]]], [450], [2], [900],
    [#link("https://store.roboticsbd.com/motor/2674-dsservo-ds3218-20kg-digital-metal-servo-with-metal-servo-horn-270-degree-robotics-bangladesh.html")[DSServo DS3218 20KG Digital Metal Servo [4]]], [2350], [2], [4700],
    [#link("https://techshopbd.com/product/servo-motor-mg996r")[Servo Motor MG996R [5]]], [500], [1], [500],
    [#link("https://store.roboticsbd.com/motor/20-servo-motor-micro-sg90-180-degree-rotation-robotics-bangladesh.html")[Servo Motor SG90 (Micro) [6]]], [180], [2], [360],

    // --- Sensors ---
    table.cell(rowspan: 14, align: left)[*Sensors*],
    
    [#link("https://www.electronics.com.bd/microcontroller/hc-sr04-ultrasonic-distance-sensor-module?srsltid=AfmBOopJht3IpNdcrsEm7KPKWbP6lf_Fyqo_RHN4m-4fnfiC5-s-ok2u99")[HC-SR04 Ultrasonic Sensor [7]]], [99], [1], [99],
    [#link("https://www.electronics.com.bd/microcontroller/infrared-obstacle-avoidance-ir-sensor-module-fc-51")[FC-51 IR Obstacle Sensor [8]]], [45], [3], [135],
    [#link("https://store.roboticsbd.com/sensors/23-hc-sr501-pir-motion-sensor-robotics-bangladesh.html")[HC-SR501 PIR Motion Sensor [9]]], [93], [1], [93],
    [#link("https://www.electronics.com.bd/modules-shields/blue-ov7670-300kp-vga-camera-module-for-arduino-diy-kit")[OV7670 Camera Module [10]]], [400], [1], [400],
    [#link("https://projectkitsbd.com/product/dht11temperature-and-humidity-sensor-module")[DHT11 [11]]],[95],[1],[95],
    [#link("https://projectkitsbd.com/product/gl5516-light-dependent-photoresistor-ldr")[LDR (Light Dependent Resistor) [12]]],[5],[1],[5], 
    [#link("https://store.roboticsbd.com/audio-voice-piezo-buzzer-speech-module/3810-dfplayer-mini-mp3-player-for-diy-arduino-esp32-sound-project-dfrobot-robotics-bangladesh.html")[DFplayer [13]]],[350],[1],[350],
    [#link("https://store.roboticsbd.com/sensors/23-hc-sr501-pir-motion-sensor-robotics-bangladesh.html")[PIR Sensor [9]]], [93], [1], [93],
    [#link("https://store.roboticsbd.com/arduino-shield/313-rc522-rfid-card-reader-module-kit-android-nfc-supported-robotics-bangladesh.html")[RFID [14]]],[190],[1],[190],
    [#link("https://store.roboticsbd.com/electronics-module/702-1-channel-5v-relay-board-module-robotics-bangladesh.html")[Relay [15]]], [80], [4], [320],
    [#link("https://store.roboticsbd.com/sensors/523-analog-ph-sensor-meter-kit-for-arduino-robotics-bangladesh.html")[PH Sensor [16]]], [2584], [1], [2584],
    [#link("https://store.roboticsbd.com/sensors/145-yl-69-soil-hygrometer-humidity-soil-moisture-detection-sensor-robotics-bangladesh.html")[Moisturizer Sensor [17]]],[70],[1],[70],
    [#link("https://store.roboticsbd.com/sensors/665-rain-steam-detection-sensor-module-robotics-bangladesh.html")[Rain Sensor [18]]],[78],[1],[78],
    [#link("https://store.roboticsbd.com/sensors/679-mq-135-gas-sensor-robotics-bangladesh.html")[MQ135 [19]]],[135],[1],[135],


    // --- Power & Audio ---
    table.cell(rowspan: 3, align: left)[*Power & Audio*],
    [#link("https://store.roboticsbd.com/robotics-parts/549-breadboard-power-supply-module-33v-5v-robotics-bangladesh.html?srsltid=AfmBOoq84N24jDlTe6bSHCj2QQAccMhyLJZ1oYlA0EuL-ziFMAjPetIe76176")[Breadboard Power Supply [20]]], [76], [1], [76],
    [#link("https://store.roboticsbd.com/sound-sensor-robotics-bangladesh/2470-3-watt-8-ohm-mini-speaker-for-electronics-project-with-jst-ph20-interface-robotics-bangladesh.html")[3 Watt 8 Ohm Mini Speaker [21]]], [250], [1], [250],
    [#link("https://techshopbd.com/product/electret-microphone")[Electret Microphone [22]]], [15], [2], [30],

    // --- Mechanical & Misc ---
    table.cell(rowspan: 7, align: left)[*Mechanical & Misc*],
    [PVC Pipe], [300], [5], [1,500],
    [Pipe (Small)], [30], [5], [150],
    [#link("https://www.electronics.com.bd/microcontroller/breadboard-project-board-half-size-self-adhesive")[Half-Size Breadboard [23]]], [75], [2], [150],
    [#link("https://www.electronics.com.bd/connectors-price-in-Bangladesh/male-male-jumper-wires")[Jumper Wires (Male-Male) [24]]], [100], [4], [400],
    [#link("https://store.roboticsbd.com/connector/1130-cable-for-arduino-unomega-usb-a-to-b-1feet-robotics-bangladesh.html")[USB Cable (Arduino) [25]]], [150], [2], [300],
    [Screws / Hardware], [100], [10], [1,000],
    [#link("https://www.electronics.com.bd/components-price-in-Bangladesh/5-meter-copper-wire-26-swg-magnet-enameled")[Copper Wire (26 SWG) [26]]], [110], [2], [220],
    
    // --- Tools ---
    table.cell(rowspan: 3, align: left)[*Tools*],
    [#link("https://www.daraz.com.bd/products/first-deal-best-quality-digital-scale-10kg-1g-household-weight-scales-platform-electronic-balance-kitchen-scale-baking-measure-food-cooking-tools-i368372677.html")[Digital Scale (10kg) [27]]], [259], [1], [259],
    [Hex Saw], [15], [2], [30],
    [Sand Paper], [30], [3], [90],

    // --- Total ---
    table.cell(colspan: 4, align: right, fill: luma(240))[*Grand Total Estimated Cost*],
    table.cell(fill: luma(240))[*31488*],
  ),
  caption: "Detailed Budget Estimation",
)

= Cost-Benefit Analysis

To evaluate the financial feasibility and practical viability of the "Farm Droid", here's a comprehensive Cost-Benefit Analysis. This analysis contrasts the initial development and operational costs against the tangible and intangible benefits generated over a projected 3-year operational lifecycle.

== Cost Breakdown
The costs are divided into initial capital expenditures (CapEx) and recurring operational expenditures (OpEx).

#figure(
  table(
    columns: (auto, auto, auto),
    fill: (col, row) => if row == 0 { luma(230) } else { white },
    align: (left, right, right),
    [*Cost Category*], [*Amount (BDT)*], [*Amount (USD)*],
    
    [*Capital Expenditure (CapEx)*], [33,000], [270],
    [*Operational Expenditure (OpEx - Annual)*], [3,000], [25],
    table.cell(colspan: 2, align: right, fill: luma(240))[*Total Estimated Cost Over 3 Years*], [42,000]
  ),
  caption: "Cost Breakdown and Total Estimated Cost Over 3 Years",
)

== Benefit Analysis

#figure(
  table(
    columns: (auto, auto),
    fill: (col, row) => if row == 0 { luma(230) } else { white },
    align: (left, left),
    [*Benefit Type*], [*Description*],
    
    [*Tangible Benefits*], [Automated labor savings, yield protection through early detection, and resource efficiency lead to an estimated annual financial benefit of BDT 27,000.],
    [*Intangible Benefits*], [Soil preservation through reduced compaction, data-driven insights for better crop management, and improved safety for farm workers.]
  ),
  caption: "Summary of Tangible and Intangible Benefits",
)

// == Financial Metrics
// Using a conservative straight-line method with no discount rate for a low-cost prototype, the financial metrics are derived as follows:

// - *Net Annual Benefit:* $text("Annual Benefits") - text("Annual OpEx") = 27,000 - 3,000 = 24,000$

// - *Simple Payback Period:*
//   $text("Total CapEx") / text("Net Annual Benefit") = 33,000 / 24,000 = 1.385\ text("years") approx 16.6\ text("months")$

// - *3-Year Return on Investment (ROI):*
//   $((text("Total 3-Year Net Benefits") - text("CapEx")) / text("CapEx")) times 100% = ((72,000 - 33,000) / 33,000) times 100% = 118.18%$

== Market Comparison: Farm Droid vs. Commercial Alternatives

The total estimated budget translates to approximately *258 USD* (assuming an exchange rate of ~122 BDT/USD). Comparing with commercial robots, we get the following insights:
#figure(
  table(
    columns: (auto, auto, 1fr, auto),
    fill: (col, row) => if row == 0 { luma(230) } else { white },
    align: (left, left, left, right),
    [*Robot Model*], [*Brand*], [*Primary Function*], [*Price (USD)*],
    
    [*Farm Droid (Our Prototype)*], [*Custom*], [*Precision Monitoring & Manipulation*], [*258*],
    [ATEAGO 50W [28]], [ATEAGO], [Remote Lawn & Terrain Maintenance], [4,798],
    [ATEAGO 50PRO [29]], [ATEAGO], [Remote Lawn & Terrain Maintenance], [7,199],
    [ATEAGO 80PRO [30]], [ATEAGO], [Heavy Terrain Maintenance], [14,999],
    [ADIR Basic [31]], [Ant Robotics], [Autonomous Ag-Logistics & Scouting], [23,292],
    [ADIR Power [32]], [Ant Robotics], [Heavy Autonomous Ag-Logistics], [29,115],
  ),
  caption: "Price Comparison with Commercial Agriculture Robots (Source: RobotShop)",
)

= Work Plan (Timeline)

#figure(
    table(
    columns: (auto, 1fr, 1fr, 1fr, 1fr, 1fr, 1fr),
    fill: (col, row) => if row == 0 { luma(230) } else { white },
    [*Task*], [*Month 1*], [*Month 2*], [*Month 3*], [*Month 4*], [*Month 5*], [*Month 6*],
    [Requirement Analysis & Planning], [✓], [], [], [], [], [],
    [Mechanical Assembly (Chassis & Drive)], [✓], [✓], [], [], [], [],
    [Circuit Integration & Power Distribution], [], [✓], [✓], [], [], [],
    [Sensor Installation & Wiring], [], [✓], [✓], [], [], [],
    [Motor Control & Calibration], [], [], [✓], [✓], [], [],
    [Arm Control & Actuation Testing], [], [], [], [✓], [✓], [],
    [Software Integration], [], [], [], [✓], [✓], [✓],
    [System Testing & Debugging], [], [], [], [], [✓], [✓],
    [Final Review & Documentation], [], [], [], [], [], [✓],
  ),
  caption: "Gantt Chart for Farm Droid Development",
)
   
= Visual Models

== Circuit Diagram

#figure(
image("ui/circuit_image.jpg", width: 100%),
caption: "Circuit Diagram of Farm Droid System",
)

This diagram includes only the parts that were implemented in the mid-term report. The final report will include the complete circuit diagram with all components and connections.

== Data Flow Diagram


#figure(
image("ui/dfd.png", width: 100%),
caption: "Data Flow Diagram of Farm Droid System",
)


= Future Plans

+ *Modular Attachments:* We plan to design and implement modular attachments for the robotic arm, such as a weeding tool, a seed dispenser, and a watering nozzle. This will allow the robot to perform a wider range of agricultural tasks.

= Conclusion
Farm Droid represents a step towards modernizing agriculture through robotics. By combining autonomous mobility with computer vision, this project aims to demonstrate that farming automation can be agile, intelligent, and accessible. The successful completion of this project will provide a functional prototype capable of navigating autonomous paths and performing basic agricultural tasks.

= References

- [1] Raspberry Pi 4 Model B (4GB) - DFRobot. (n.d.). Retrieved from https://techshopbd.com/product/raspberry-pi-4-model-b-4gb-brand-dfrobot
- [2] Arduino Uno R3. (n.d.). Retrieved from https://store.roboticsbd.com/development-boards/94-8-arduino-uno-r3-robotics-bangladesh.html
- [3] GA25 Metal Gear Motor. (n.d.). Retrieved from https://projectkitsbd.com/product/370ga25-dc6-12v-metal-gear-motors
- [4] DSServo DS3218 20KG Digital Metal Servo. (n.d.). Retrieved from https://store.roboticsbd.com/motor/2674-dsservo-ds3218-20kg-digital-metal-servo-with-metal-servo-horn-270-degree-robotics-bangladesh.html
- [5] Servo Motor MG996R. (n.d.). Retrieved from https://techshopbd.com/product/servo-motor-mg996r
- [6] Servo Motor Micro SG90. (n.d.). Retrieved from https://store.roboticsbd.com/motor/20-servo-motor-micro-sg90-180-degree-rotation-robotics-bangladesh.html
- [7] HC-SR04 Ultrasonic Sensor. (n.d.). Retrieved from https://www.electronics.com.bd/microcontroller/hc-sr04-ultrasonic-distance-sensor-module
- [8] FC-51 IR Obstacle Sensor. (n.d.). Retrieved from https://www.electronics.com.bd/microcontroller/infrared-obstacle-avoidance-ir-sensor-module-fc-51
- [9] HC-SR501 PIR Motion Sensor. (n.d.). Retrieved from https://store.roboticsbd.com/sensors/23-hc-sr501-pir-motion-sensor-robotics-bangladesh.html
- [10] OV7670 Camera Module. (n.d.). Retrieved from https://www.electronics.com.bd/modules-shields/blue-ov7670-300kp-vga-camera-module-for-arduino-diy-kit
- [11] DHT11 Temperature and Humidity Sensor Module. (n.d.). Retrieved from https://projectkitsbd.com/product/dht11temperature-and-humidity-sensor-module
- [12] GL5516 Light Dependent Photoresistor LDR. (n.d.). Retrieved from https://projectkitsbd.com/product/gl5516-light-dependent-photoresistor-ldr
- [13] DFPlayer Mini MP3 Player. (n.d.). Retrieved from https://store.roboticsbd.com/audio-voice-piezo-buzzer-speech-module/3810-dfplayer-mini-mp3-player-for-diy-arduino-esp32-sound-project-dfrobot-robotics-bangladesh.html
- [14] RC522 RFID Card Reader Module. (n.d.). Retrieved from https://store.roboticsbd.com/arduino-shield/313-rc522-rfid-card-reader-module-kit-android-nfc-supported-robotics-bangladesh.html
- [15] 1-Channel 5V Relay Board Module. (n.d.). Retrieved from https://store.roboticsbd.com/electronics-module/702-1-channel-5v-relay-board-module-robotics-bangladesh.html
- [16] Analog pH Sensor Meter Kit. (n.d.). Retrieved from https://store.roboticsbd.com/sensors/523-analog-ph-sensor-meter-kit-for-arduino-robotics-bangladesh.html
- [17] YL-69 Soil Hygrometer Moisture Sensor. (n.d.). Retrieved from https://store.roboticsbd.com/sensors/145-yl-69-soil-hygrometer-humidity-soil-moisture-detection-sensor-robotics-bangladesh.html
- [18] Rain/Steam Detection Sensor Module. (n.d.). Retrieved from https://store.roboticsbd.com/sensors/665-rain-steam-detection-sensor-module-robotics-bangladesh.html
- [19] MQ-135 Gas Sensor. (n.d.). Retrieved from https://store.roboticsbd.com/sensors/679-mq-135-gas-sensor-robotics-bangladesh.html
- [20] Breadboard Power Supply Module. (n.d.). Retrieved from https://store.roboticsbd.com/robotics-parts/549-breadboard-power-supply-module-33v-5v-robotics-bangladesh.html
- [21] 3 Watt 8 Ohm Mini Speaker. (n.d.). Retrieved from https://store.roboticsbd.com/sound-sensor-robotics-bangladesh/2470-3-watt-8-ohm-mini-speaker-for-electronics-project-with-jst-ph20-interface-robotics-bangladesh.html
- [22] Electret Microphone. (n.d.). Retrieved from https://techshopbd.com/product/electret-microphone
- [23] Half-Size Breadboard. (n.d.). Retrieved from https://www.electronics.com.bd/microcontroller/breadboard-project-board-half-size-self-adhesive
- [24] Jumper Wires (Male-Male). (n.d.). Retrieved from https://www.electronics.com.bd/connectors-price-in-Bangladesh/male-male-jumper-wires
- [25] USB Cable for Arduino. (n.d.). Retrieved from https://store.roboticsbd.com/connector/1130-cable-for-arduino-unomega-usb-a-to-b-1feet-robotics-bangladesh.html
- [26] Copper Wire (26 SWG). (n.d.). Retrieved from https://www.electronics.com.bd/components-price-in-Bangladesh/5-meter-copper-wire-26-swg-magnet-enameled
- [27] Digital Scale (10kg). (n.d.). Retrieved from https://www.daraz.com.bd/products/first-deal-best-quality-digital-scale-10kg-1g-household-weight-scales-platform-electronic-balance-kitchen-scale-baking-measure-food-cooking-tools-i368372677.html
- [28] ATEAGO 50W Robotic Lawn Mower. (n.d.). Retrieved from https://www.robotshop.com/products/ateago-ateago-50w-remote-control-lawn-mower-robot-lawn-maintenance-grass-clean-for-garden-or-hill?qd=1aa0ec8ac9c7c76afc6866d7f11a121b
- [29] ATEAGO 50PRO Robotic Lawn Mower. (n.d.). Retrieved from https://www.robotshop.com/collections/agriculture-robots
- [30] ATEAGO 80PRO Robotic Lawn Mower. (n.d.). Retrieved from https://www.robotshop.com/products/ateago-ateago-50pro-remote-control-lawn-mower-robot-lawn-maintenance-robot-grass-clean-for-garden-or-hill?qd=1aa0ec8ac9c7c76afc6866d7f11a121b
- [31] ADIR Basic Autonomous Agricultural Robot. (n.d.). Retrieved from https://www.robotshop.com/products/ant-robotics-adir-basic?qd=1aa0ec8ac9c7c76afc6866d7f11a121b
- [32] ADIR Power Autonomous Agricultural Robot. (n.d.). Retrieved from https://www.robotshop.com/products/ant-robotics-adir-power?qd=1aa0ec8ac9c7c76afc6866d7f11a121b

#align(center + bottom)[
  #v(2em)
  *The End*
]